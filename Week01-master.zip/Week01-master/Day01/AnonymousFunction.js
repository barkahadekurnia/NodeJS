function all() {
    setTimeout(function () {
        console.log('Hai');
    },1000)
    setTimeout(function () {
        console.log('Saya Naufal');
    },2000)
}
all()