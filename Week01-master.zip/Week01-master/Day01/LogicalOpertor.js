let istrue = true && true
console.log(istrue);

let isFalse = true && false
console.log(isFalse);

istrue = 10===10 && 10!==11
console.log(istrue);

istrue = true || false
console.log(istrue);

isFalse = false || false
console.log(isFalse);

isFalse = 10 === '10'
console.log(isFalse);