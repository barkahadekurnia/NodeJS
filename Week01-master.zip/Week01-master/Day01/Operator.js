console.log(15 > 12);
console.log(10.5<10.4);

console.log(12=='12');


console.log(12==='12');

console.log(Number.MAX_SAFE_INTEGER);
console.log(Number.MIN_SAFE_INTEGER);
console.log(Infinity);
console.log(Number.MAX_SAFE_INTEGER>Infinity);

