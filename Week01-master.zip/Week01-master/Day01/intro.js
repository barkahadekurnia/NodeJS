console.log('Halo');

console.log('Hai selamt datang di bootcamp');