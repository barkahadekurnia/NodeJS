const arr = [1,2,3]
console.log(typeof arr);

const obj = {
    nama  : 'js',
    ipk : 3.14
}

console.log(typeof obj);

function name() {
    return 'hallo'
}

console.log(typeof name);