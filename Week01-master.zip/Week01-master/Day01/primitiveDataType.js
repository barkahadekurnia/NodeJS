const result = true
console.log(typeof result);

const s = 'Hai'
console.log(typeof s);

const a = 123
console.log(typeof a);

const undef = undefined
console.log(typeof undef);

const sym = Symbol('1')
console.log(typeof sym);