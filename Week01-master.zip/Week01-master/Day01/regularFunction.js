function SayHello() {
    return 'Hai Semua'
}
console.log(SayHello());

function MyName(firstName) {
    return `Hai Saya ${firstName}`
}
console.log(MyName('Naufal'));

function MyNames(firstName,lastName) {
    return `Hai Saya ${firstName}${lastName}`
}
console.log(MyNames('Naufal','Firdaus'));

