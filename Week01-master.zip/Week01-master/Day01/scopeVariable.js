const arr = [1,2,3,4]
arr.push(12)
arr.unshift(14)
console.log(arr);

let arr1 = [1,2,3,4]
arr1 = [1,2]
console.log(arr1);